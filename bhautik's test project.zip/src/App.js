import React, { useState } from "react";
import "./App.css";
import {
  FormControl,
  InputLabel,
  Input,
  Stack,
  TextField,
  Checkbox,
  FormControlLabel
} from "@mui/material";

function App() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    fullName: "",
    dl: "",
    dlNumber: "",
    dob: new Date(),
  });
  const handleChange = (e) => {
    const {name,value}= e.target
    console.log("value",e.target);
    setFormData((prevState)=>{
      return{
        ...prevState,
        [name]:value,
      }
    })
  };
  const handleSubmit = (e) => {
    // e.preventDefault()
  };
  function getAge(DOB) {
    var today = new Date();
    var birthDate = new Date(DOB);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }    
    return age;
}

  console.log("formData",formData);
  return (
    <div className="App">
      {/* <form onSubmit={handleSubmit}> */}
      <Stack
        component="form"
        sx={{
          width: "50%",
          margin:"60px",
        }}
        spacing={2}
      >
        <FormControl>
          <InputLabel htmlFor="my-input">Email address</InputLabel>
          <Input
            id="email"
            aria-describedby="my-helper-text-email"
            type="email"
            placeholder="Enter E-mail"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
        </FormControl>

        <FormControl>
          <InputLabel htmlFor="my-input">password</InputLabel>
          <Input
            id="password"
            aria-describedby="my-helper-text-email"
            type="password"
            placeholder="Enter password"
            name="password"
            onChange={handleChange}
            value={formData.password}

          />
        </FormControl>
        <FormControl>
          <InputLabel htmlFor="my-input">Full Name</InputLabel>
          <Input
            id="fullName"
            aria-describedby="my-helper-text"
            type="text"
            placeholder="full Name"
            name="fullName"
            onChange={handleChange}
            value={formData.fullName}
          />
        </FormControl>
        <FormControl>
          {/* <InputLabel htmlFor="my-input">Date of Birth</InputLabel> */}
          <Input
            id="dob"
            aria-describedby="my-helper-text"
            type="date"
            placeholder="Dob"
            name="dob"
            onChange={handleChange}
            value={formData.dob}
          />
        </FormControl>
        <FormControl>
           <FormControlLabel control={<Checkbox defaultChecked />} label="Driving license" />
        </FormControl>
        <FormControl>
          <InputLabel htmlFor="my-input">Driving license number</InputLabel>
          <Input
            id="dlNumber"
            aria-describedby="my-helper-text"
            type="text"
            placeholder="full Name"
            name="dlNumber"
            onChange={handleChange}
            value={formData.dlNumber}
          />
        </FormControl>
      </Stack>
    </div>
  );
}

export default App;
